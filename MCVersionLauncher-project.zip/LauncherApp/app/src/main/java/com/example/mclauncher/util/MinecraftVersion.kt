package com.example.mclauncher.util

import android.graphics.drawable.Drawable

data class MinecraftVersion(
    val label: String,
    val packageName: String,
    val versionName: String,
    val icon: Drawable?
)

package com.example.mclauncher

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mclauncher.adapter.VersionAdapter
import com.example.mclauncher.util.PackImporter
import com.example.mclauncher.util.VersionScanner
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { handlePickedFile(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedTheme()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.versionRecycler)
        recycler.layoutManager = LinearLayoutManager(this)

        findViewById<android.widget.Button>(R.id.importPackButton).setOnClickListener {
            filePicker.launch(arrayOf("*/*"))
        }

        findViewById<android.widget.Button>(R.id.themeButton).setOnClickListener {
            showThemeDialog()
        }

        loadVersions()
    }

    override fun onResume() {
        super.onResume()
        loadVersions()
    }

    private fun loadVersions() {
        val versions = VersionScanner.scanInstalled(this)
        val emptyView = findViewById<android.widget.TextView>(R.id.emptyView)

        if (versions.isEmpty()) {
            recycler.visibility = android.view.View.GONE
            emptyView.visibility = android.view.View.VISIBLE
        } else {
            recycler.visibility = android.view.View.VISIBLE
            emptyView.visibility = android.view.View.GONE
            recycler.adapter = VersionAdapter(versions) { version ->
                VersionScanner.launch(this, version.packageName)
            }
        }
    }

    private fun handlePickedFile(uri: Uri) {
        val name = queryFileName(uri) ?: "pack"
        contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        PackImporter.importPack(this, uri, name)
    }

    private fun queryFileName(uri: Uri): String? {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) return it.getString(idx)
        }
        return null
    }

    private fun showThemeDialog() {
        val options = arrayOf("Sáng", "Tối", "Theo hệ thống")
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val current = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        val selected = when (current) {
            AppCompatDelegate.MODE_NIGHT_NO -> 0
            AppCompatDelegate.MODE_NIGHT_YES -> 1
            else -> 2
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Chọn giao diện")
            .setSingleChoiceItems(options, selected) { dialog, which ->
                val mode = when (which) {
                    0 -> AppCompatDelegate.MODE_NIGHT_NO
                    1 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
                prefs.edit().putInt("theme_mode", mode).apply()
                AppCompatDelegate.setDefaultNightMode(mode)
                dialog.dismiss()
                recreate()
            }
            .show()
    }

    private fun applySavedTheme() {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val mode = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(mode)
    }
}

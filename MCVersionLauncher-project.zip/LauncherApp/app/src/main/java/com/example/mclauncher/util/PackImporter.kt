package com.example.mclauncher.util

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Import resource pack / behavior pack / world template.
 *
 * Cách làm ĐÚNG và AN TOÀN: không tự ý ghi vào thư mục dữ liệu riêng
 * của Minecraft (bị chặn bởi scoped storage từ Android 11+, và app khác
 * không nên cố lách qua). Thay vào đó, ta chuyển file cho chính Minecraft
 * xử lý bằng ACTION_VIEW — giống hệt việc người dùng bấm vào file .mcpack
 * trong trình quản lý file. Minecraft sẽ tự hỏi và tự import.
 */
object PackImporter {

    private fun mimeFor(fileName: String): String = when {
        fileName.endsWith(".mcpack") -> "application/mcpack"
        fileName.endsWith(".mcaddon") -> "application/mcaddon"
        fileName.endsWith(".mcworld") -> "application/mcworld"
        fileName.endsWith(".mctemplate") -> "application/mctemplate"
        else -> "application/octet-stream"
    }

    fun importPack(context: Context, uri: Uri, fileName: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeFor(fileName))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}

package com.example.mclauncher.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mclauncher.R
import com.example.mclauncher.util.MinecraftVersion

class VersionAdapter(
    private val items: List<MinecraftVersion>,
    private val onLaunch: (MinecraftVersion) -> Unit
) : RecyclerView.Adapter<VersionAdapter.VH>() {

    class VH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.iconView)
        val label: TextView = itemView.findViewById(R.id.labelView)
        val version: TextView = itemView.findViewById(R.id.versionView)
        val launchBtn: android.widget.Button = itemView.findViewById(R.id.launchButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_version, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.icon.setImageDrawable(item.icon)
        holder.label.text = item.label
        holder.version.text = "Phiên bản: ${item.versionName}"
        holder.launchBtn.setOnClickListener { onLaunch(item) }
    }

    override fun getItemCount() = items.size
}

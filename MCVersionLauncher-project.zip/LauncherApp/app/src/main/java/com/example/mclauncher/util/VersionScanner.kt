package com.example.mclauncher.util

import android.content.Context
import android.content.pm.PackageManager

/**
 * Quét các bản Minecraft: Bedrock Edition ĐÃ CÀI HỢP LỆ trên thiết bị
 * (qua Google Play, hoặc APK do người dùng tự cài chính chủ).
 * Không tải, không patch, không bypass license — chỉ liệt kê những gì
 * hệ thống báo là đã cài.
 */
object VersionScanner {

    private val KNOWN_PACKAGES = listOf(
        "com.mojang.minecraftpe" to "Minecraft (Bedrock)",
        "com.mojang.minecraftpebeta" to "Minecraft Preview",
        "com.mojang.minecrafteducationedition" to "Minecraft Education"
    )

    fun scanInstalled(context: Context): List<MinecraftVersion> {
        val pm = context.packageManager
        val result = mutableListOf<MinecraftVersion>()

        for ((pkg, label) in KNOWN_PACKAGES) {
            try {
                val info = pm.getPackageInfo(pkg, 0)
                val appInfo = pm.getApplicationInfo(pkg, 0)
                result.add(
                    MinecraftVersion(
                        label = label,
                        packageName = pkg,
                        versionName = info.versionName ?: "?",
                        icon = pm.getApplicationIcon(appInfo)
                    )
                )
            } catch (e: PackageManager.NameNotFoundException) {
                // Chưa cài bản này — bỏ qua, không làm gì thêm
            }
        }
        return result
    }

    fun launch(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            context.startActivity(intent)
        }
    }
}
